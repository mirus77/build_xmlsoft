#!/bin/bash
SRCDIR=../libiconv-1.14
BASEDIR=`dirname $0`

function makedirs () {
  echo == MakeDirs ==
  if [ ! -d "${BASEDIR}/include" ]; then mkdir -p "${BASEDIR}/include"; fi;
  if [ ! -d "${BASEDIR}/src" ]; then mkdir -p "${BASEDIR}/src"; fi;
}

function copyfirst () {
  echo == CopyFirst ==
  if [ ! -f "${BASEDIR}/src/relocatable.h" ]; then cp ${SRCDIR}/lib/relocatable.h ${BASEDIR}/src/; fi;
  if [ ! -f "${BASEDIR}/src/relocatable.c" ]; then cp ${SRCDIR}/lib/relocatable.c ${BASEDIR}/src/; fi;
  if [ ! -f "${BASEDIR}/src/iconv.c" ]; then cp ${SRCDIR}/lib/iconv.c ${BASEDIR}/src/; fi;
  if [ ! -f "${BASEDIR}/src/localcharset.h" ]; then cp ${SRCDIR}/libcharset/include/localcharset.h.build.in ${BASEDIR}/src/localcharset.h; fi;
  if [ ! -f "${BASEDIR}/src/localcharset.c" ]; then cp ${SRCDIR}/libcharset/lib/localcharset.c ${BASEDIR}/src/; fi;
  if [ ! -f "${BASEDIR}/src/libiconv.rc" ]; then cp ${SRCDIR}/windows/libiconv.rc ${BASEDIR}/src/; fi;
  if [ ! -f "${BASEDIR}/include/iconv.h" ]; then cp ${SRCDIR}/include/iconv.h.build.in ${BASEDIR}/include/iconv.h; fi;
  if [ ! -f "${BASEDIR}/include/config.h" ]; then cp ${SRCDIR}/config.h.in ${BASEDIR}/include/config.h; fi;
  if [ ! -f "${BASEDIR}/include/cp1046.h" ]; then cp ${SRCDIR}/lib/*.h ${SRCDIR}/lib/*.def ${BASEDIR}/include/; fi;
}

echo == Init build dir ==
if [ ! -f "${BASEDIR}/src/iconv.c" ]; then
  makedirs
  copyfirst
fi

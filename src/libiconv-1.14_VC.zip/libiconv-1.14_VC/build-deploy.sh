#!/bin/bash
DISTDIR=../../VC141_x86
DISTDIR64=../../VC141_x64

mkdir -p ${DISTDIR}/bin
mkdir -p ${DISTDIR}/include/libiconv
mkdir -p ${DISTDIR}/lib

mkdir -p ${DISTDIR64}/bin
mkdir -p ${DISTDIR64}/include/libiconv
mkdir -p ${DISTDIR64}/lib

cp include/iconv.h ${DISTDIR}/include/libiconv/
cp include/iconv.h ${DISTDIR64}/include/libiconv/

cp bin/libiconv.dll ${DISTDIR}/bin/
cp lib/Release/*.lib ${DISTDIR}/lib/
cp lib/Release/*.pdb ${DISTDIR}/lib/
cp lib_a/Release/*_a.lib ${DISTDIR}/lib/
cp libiconv/libiconv_a.def ${DISTDIR}/lib/

cp bin64/libiconv.dll ${DISTDIR64}/bin/
cp lib64/Release/*.lib ${DISTDIR64}/lib/
cp lib64/Release/*.pdb ${DISTDIR64}/lib/
cp lib64_a/Release/*_a.lib ${DISTDIR64}/lib/
cp libiconv/libiconv_a.def ${DISTDIR64}/lib/

  libeetsigner 1.0.2
  ------------------

  This is libeetsigner, version 1.0.2, binary package for the native win32
platform.

  The files in this package require "Microsoft Visual C++ 2013 Redistributable (x86)".
  
  Extract the contents of the archive whereever you wish and
make sure that your tools which use libeetsigner can find it.

  For example, if you want to run the supplied utilities from the command
line, you can, if you wish, add the 'bin' subdirectory to the PATH
environment variable.
  If you want to make programmes in C which use libeetsigner, you'll
likely know how to use the contents of this package. If you don't, please
refer to your compiler's documentation.

  If there is something you cannot keep for yourself, such as a problem,
a cheer of joy, a comment or a suggestion, feel free to contact me using
the address below.

Miroslav Kundela (mail@mirus.cz)
